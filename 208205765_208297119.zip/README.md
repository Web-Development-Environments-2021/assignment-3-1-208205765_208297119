# assignment-3-1-208205765_208297119
assignment-3-1-208205765_208297119 created by GitHub Classroom
https://app.swaggerhub.com/apis-docs/ronny5423/Project_3.1/3.0.3

208297119_208205765

we think the server and the client will take us 2 weeks per part
